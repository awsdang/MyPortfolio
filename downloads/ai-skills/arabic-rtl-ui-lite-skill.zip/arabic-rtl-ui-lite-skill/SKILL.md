---
name: arabic-rtl-ui-lite
author: awsdang
email: awsdang@gmail.com
edition: free
version: 1.0.0
description: >
  A practical free starter skill for creating Arabic RTL interfaces on web and
  mobile. Covers the essential rules for direction, alignment, navigation,
  common inputs, Arabic copy, gestures, and basic quality checks.
---

# Arabic RTL UI Lite

A compact starter skill for building Arabic right-to-left interfaces that feel intentional rather than mechanically flipped.

Use it for:

- Web and responsive web
- Flutter
- React Native
- Native iOS and Android
- Arabic-only products
- Arabic and English products
- Adding RTL to an existing LTR interface
- Starting a new RTL-first interface

This Lite edition focuses on the rules that prevent the most common and visible Arabic UI mistakes.

---

# Essential rules

1. Set the actual interface direction to RTL.
2. Align Arabic text explicitly to the right.
3. Align email, password, URL, phone, OTP, and code fields explicitly to the left and keep them LTR.
4. Do not use `text-start`, `text-end`, `text-align: start`, or `text-align: end` for critical alignment.
5. Never use `row-reverse`, `flex-reverse`, or reversed arrays as a quick RTL solution.
6. Keep the original logical item order.
7. Place the back button on the right and use a right-pointing chevron.
8. Place the next button on the left and use a left-pointing chevron.
9. Place the close button at the top-left in RTL layouts.
10. Sliders and progress bars begin at 0 on the right and end at 100 on the left.
11. In an RTL gallery, swipe from left to right to reveal the next item.
12. Never reverse phone numbers, IDs, dates, URLs, email addresses, or numeric values.
13. Do not show English backend errors to Arabic users.
14. Use Western numerals `0123456789` unless the product explicitly requires another format.
15. Put all multilingual UI text in localization files instead of hard-coding it in components.

---

# Direction and text alignment

Set direction at the screen or application level.

Web:

```html
<html lang="ar" dir="rtl">
```

```css
.arabic-screen {
  direction: rtl;
}

.arabic-text {
  direction: rtl;
  text-align: right;
}
```

Do not rely on direction alone to align important text.

Bad:

```css
.arabic-text {
  text-align: end;
}
```

Good:

```css
.arabic-text {
  direction: rtl;
  text-align: right;
}
```

For LTR content inside Arabic screens:

```css
.ltr-value {
  direction: ltr;
  text-align: left;
}
```

Use this for:

- Email addresses
- Passwords
- URLs
- Phone numbers
- OTP codes
- Usernames
- Order numbers
- File paths
- Technical identifiers

---

# Never reverse the layout lazily

Do not use these as general RTL fixes:

```css
flex-direction: row-reverse;
```

```tsx
items.reverse()
```

```dart
children.reversed.toList()
```

They commonly create incorrect visual order, keyboard order, accessibility order, arrows, and touch behaviour.

Keep data and source order logical. Apply RTL direction to the correct container and position special controls explicitly.

---

# Navigation

## Back

In Arabic RTL:

- Place back on the right
- Use a right-pointing chevron
- Keep it separate from the title

Concept:

```text
[›]  عنوان الصفحة
```

## Next

In Arabic RTL:

- Place next on the left
- Use a left-pointing chevron

Concept:

```text
عنوان الصفحة  [‹]
```

## Close

In Arabic RTL:

- Close appears at the top-left

In LTR:

- Close appears at the top-right

Choose the correct icon directly. Do not blindly mirror SVGs with `scaleX(-1)`.

---

# Icons

Usually keep these icons visually unchanged:

- Play
- Pause
- Search
- Camera
- Microphone
- Download
- Upload
- Settings
- Location pin
- Lock
- Trash

Their placement may change, but the symbol itself usually should not be mirrored.

Directional actions such as back, next, previous, reply, and forward must be checked intentionally.

---

# Touch behaviour

RTL must affect interaction, not only appearance.

## Galleries and carousels

To reveal the next Arabic item:

- Swipe from left to right

To return to the previous item:

- Swipe from right to left

Test the library manually. Some carousel libraries mirror the screen but keep LTR gesture logic.

## Sliders and progress

In RTL:

- 0 is on the right
- 100 is on the left
- Dragging left increases the value
- Dragging right decreases the value

Test both visual direction and touch calculation.

## Switches

The switch placement and animation should feel correct in RTL. Do not assume the component library handles it perfectly.

---

# Forms

## Arabic fields

Usually use:

```text
direction: rtl
text alignment: right
```

## LTR fields

Email, password, phone, URL, OTP, and codes should usually use:

```text
direction: ltr
text alignment: left
```

## Labels

- Keep labels visible above the field
- Align Arabic labels to the right
- Do not use placeholders as the only label
- Show validation below the related field

## Password

- Keep the value LTR
- Align the value left
- Place the visibility icon intentionally
- Ensure text never overlaps the icon

## Phone number

- Keep the country code and number LTR
- Never reverse digits
- Keep the country code first in logical order

---

# Arabic UI copy

Use Arabic-only interface text unless mixed language is explicitly requested.

Choose the dialect according to the audience:

- Iraqi audience: Iraqi Arabic
- Egyptian audience: Egyptian Arabic
- Lebanese audience: Lebanese Arabic
- Gulf audience: suitable Gulf Arabic
- Multi-country or formal product: clear Arabic suitable for the context

Do not automatically use overly formal Arabic.

## Buttons

Prefer clear actions:

- `احفظ`
- `أرسل`
- `احجز الآن`
- `أضف فرداً`
- `جرّب مرة ثانية`
- `احذف الصورة`

Avoid vague labels when a specific action is available:

- `نعم`
- `موافق`
- `حسناً`
- `تم`

## Errors

An Arabic error should explain:

1. What happened
2. What the user can do next

Bad:

```text
Internal Server Error
```

Better:

```text
صار خلل من عدنا. جرّب مرة ثانية بعد شوي.
```

Map backend error codes to Arabic messages instead of displaying raw server text.

## Success messages

Prefer specific confirmation.

Instead of:

```text
تم بنجاح
```

Use:

```text
انحفظت التغييرات
```

or:

```text
انرسل الطلب
```

## Punctuation

Use:

- Arabic question mark `؟`
- Arabic comma `،`

Avoid:

- Em dashes
- Uncommon English symbols
- Excessive exclamation marks
- Ampersands in Arabic labels
- Arrow characters when a proper icon is available

---

# Numbers and symbols

Use Western numerals by default:

```text
0123456789
```

Keep numeric and technical values LTR.

Currency appears to the left of the number:

```text
د.ع 25,000
```

Percentage appears to the left:

```text
%25
```

Negative sign appears to the left:

```text
-25
```

Use bidi isolation when Arabic text contains dynamic LTR values.

Web example:

```html
<p dir="rtl" class="message">
  رقم الطلب:
  <bdi dir="ltr">ORD-2026-1058</bdi>
</p>
```

---

# Localization

For multilingual products, keep visible copy in localization resources.

Example:

```json
{
  "common": {
    "save": "احفظ",
    "cancel": "إلغاء",
    "retry": "جرّب مرة ثانية"
  },
  "errors": {
    "network": "ماكو اتصال بالإنترنت. تأكد من الشبكة وجرّب مرة ثانية."
  }
}
```

Do not hard-code visible Arabic text inside JSX, Dart, HTML, Swift, Kotlin, or component files.

Do not build sentences by concatenating translated fragments.

---

# Framework starter examples

## React Native

```tsx
const styles = StyleSheet.create({
  arabicText: {
    writingDirection: "rtl",
    textAlign: "right",
  },
  ltrInput: {
    writingDirection: "ltr",
    textAlign: "left",
  },
  backButton: {
    position: "absolute",
    right: 16,
  },
  nextButton: {
    position: "absolute",
    left: 16,
  },
});
```

Do not use `row-reverse` to repair a complete screen.

## Flutter

Arabic text:

```dart
Text(
  context.l10n.title,
  textDirection: TextDirection.rtl,
  textAlign: TextAlign.right,
)
```

LTR field:

```dart
TextField(
  textDirection: TextDirection.ltr,
  textAlign: TextAlign.left,
)
```

Use explicit left and right placement where the exact result matters.

Do not reverse widget lists for RTL.

## Web

```css
[dir="rtl"] .label,
[dir="rtl"] .title,
[dir="rtl"] .body {
  text-align: right;
}

[dir="rtl"] .email,
[dir="rtl"] .password,
[dir="rtl"] .phone,
[dir="rtl"] .code {
  direction: ltr;
  text-align: left;
}
```

---

# Basic RTL review checklist

Before release, confirm:

- Arabic text is right-aligned
- LTR values are left-aligned
- Back is on the right and points right
- Next is on the left and points left
- Close is at the top-left
- No `row-reverse` or reversed arrays are used as global fixes
- Slider begins on the right
- Next carousel gesture moves left to right
- Phone numbers and IDs are not reversed
- Backend errors appear in Arabic
- Currency and percentage symbols use the intended order
- Arabic copy comes from localization files
- Text is not clipped vertically
- Buttons and fields are visually centred with the chosen Arabic font
- The screen is tested on both iOS and Android
- RTL and LTR screenshots are reviewed

---

# Limits of the Lite edition

This Lite edition provides the core rules needed to avoid the most common Arabic RTL problems.

The full edition can include deeper guidance for:

- Complete framework-specific architecture
- Advanced bidirectional text handling
- Detailed component rules
- Accessibility and screen-reader testing
- Automated visual regression
- Arabic search normalization
- Detailed pluralization and dynamic copy
- Tables, charts, breadcrumbs, pagination, and complex navigation
- Production review workflows
- Extensive good and bad examples
- Comprehensive QA checklists
- RTL conversion of mature LTR products
- Edge cases across iOS, Android, Flutter, React Native, and web

---

# Final standard

A good Arabic RTL interface must:

- Feel designed for Arabic
- Use real RTL direction
- Align Arabic text to the right
- Keep technical values LTR
- Place back on the right
- Place next on the left
- Use correct touch direction
- Keep logical source order
- Avoid lazy reversal techniques
- Use natural Arabic copy
- Work correctly on both iOS and Android
